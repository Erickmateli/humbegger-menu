$(document).ready(function(){
	$("#mainmenu").hide();
	$("#humbegger").mouseenter(function(){
		$(this).fadeOut(2000);
		$("#mainmenu").fadeIn(1000);
	});

	$("#mainmenu").mouseleave(function(){
		$(this).fadeOut(3000);
		$("#humbegger").fadeIn(1000);
			return false;
	});

});